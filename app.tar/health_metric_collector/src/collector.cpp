/*
 * Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

#include <aws/core/utils/logging/LogMacros.h>
//#include <aws_ros1_common/sdk_utils/ros1_node_parameter_reader.h>
#include <health_metric_collector/cpu_metric_collector.h>
#include <health_metric_collector/metric_collector.h>
#include <health_metric_collector/metric_manager.h>
#include <health_metric_collector/sys_info_collector.h>
#include <rclcpp/rclcpp.hpp>
#include <ros_monitoring_msgs/msg/metric_list.hpp>

#include <vector>
#include <chrono>

using namespace std::chrono_literals;

#define DEFAULT_INTERVAL_SEC 5
#define TOPIC_BUFFER_SIZE 1000
#define INTERVAL_PARAM_NAME "interval"
#define ROBOT_ID_DIMENSION "robot_id"
#define CATEGORY_DIMENSION "category"
#define HEALTH_CATEGORY "RobotHealth"
#define DEFAULT_ROBOT_ID "Default_Robot"
#define DEFAULT_NODE_NAME "health_metric_collector"
#define INTERVAL_PARAM_NAME "interval"
#define METRICS_TOPIC_NAME "metrics"

//using namespace ros_monitoring_msgs;

class Talker : public rclcpp::Node
{
public:

  std::vector<MetricCollectorInterface *> collectors_;
  MetricManager& mg_;
rclcpp::Publisher<msg::MetricList>::SharedPtr publisher_;

  explicit Talker(MetricManager& mg, std::vector<MetricCollectorInterface *> collectors)
  : Node("talker"), mg_(mg), collectors_(collectors)
  {
    RCLCPP_INFO(this->get_logger(), "%s Starting Health Metric Collector Node...", __func__);

    publisher_ = this->create_publisher<ros_monitoring_msgs::msg::MetricList>(METRICS_TOPIC_NAME, rmw_qos_profile_default);

    // Create a function for when messages are to be sent.
    auto publish_message = [this]()
    {
      for (auto& c : collectors_) {
        c->Collect();
      }
      RCLCPP_INFO(this->get_logger(), "%s size of list = %d", __func__, mg_.GetMetrics().metrics.size());
      publisher_->publish(mg_.GetMetrics());
      mg_.Publish();
    };

    // Use a timer to schedule periodic message publishing.
    timer_ = this->create_wall_timer(1s, publish_message);
  }

private:
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);

/*
  auto param_reader = std::make_shared<Aws::Client::Ros1NodeParameterReader>();

  // get interval param
  double interval = DEFAULT_INTERVAL_SEC;
  param_reader->ReadDouble(INTERVAL_PARAM_NAME, interval);

  // get robot id
  std::string robot_id = DEFAULT_ROBOT_ID;
  param_reader->ReadStdString(ROBOT_ID_DIMENSION, robot_id);
*/

  RCLCPP_INFO(rclcpp::get_logger("main"), "start");

  MetricManager mg;
  mg.AddDimension(ROBOT_ID_DIMENSION, "robot_id");
  mg.AddDimension(CATEGORY_DIMENSION, HEALTH_CATEGORY);

  std::vector<MetricCollectorInterface *> collectors;
  CPUMetricCollector cpu_collector(mg);
  collectors.push_back(&cpu_collector);

  SysInfoCollector sys_collector(mg);
  collectors.push_back(&sys_collector);

  auto node_talker = std::make_shared<Talker>(mg, collectors);
  rclcpp::spin(node_talker);

  rclcpp::shutdown();
  return 0;
}
